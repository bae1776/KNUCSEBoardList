package bae1776.first.gather_informations;

import java.util.LinkedList;


public abstract class InfoBoard {
    public InfoBoard() {
        postList = new LinkedList<InfoPost>();
    }
    LinkedList<InfoPost> postList;
    Thread networkThread;
    //아래 두 변수는 반드시 상속받은 클래스가 생성자에서 값을 명시해야함.
    String rootURL;
    String InfoBoardName;
    int boardPage = 1;
    public abstract InfoBoard getInfoPostData();  //Thread에서 인터넷 연결을 통해 정보를 받아오는 메소드
    public void setNextPage() {
        this.boardPage++;
    }
    protected abstract void setRootURLAgain();
}
