package bae1776.first.gather_informations;

public class InfoPost {
        //글 하나의 정보를 담고 있음.

        public InfoPost() {
            this.bbs_date = new SimpleDate();
        }

        public String postResource; //글 출처
        public String bbs_num; //글 번호
        public String title; //글 제목
        public String bbs_writer; //작성자
        public SimpleDate bbs_date; //작성 날짜
        public String bbs_hit; //조회수
        public String clickLink; //눌렀을 때 연결할 페이지

        public String toString() {
            return "\n글 출처 : " + postResource + "\n글 번호 : " + bbs_num + "\n글 제목 : " + title + "\n작성자 : " + bbs_writer
                    + "\n작성 날짜 : " + bbs_date + "\n조회수 : " + bbs_hit + "\n클릭하면 이동할 링크 : " + clickLink;
        }
}
