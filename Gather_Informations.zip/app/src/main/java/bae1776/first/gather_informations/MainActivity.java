package bae1776.first.gather_informations;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.Toast;

import com.first.gather_informations.R;

import java.util.Vector;

public class MainActivity extends Activity {

    static final int CHECKCOUNT = 3;

    OnClickListener chkBoxListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            if (((CheckedTextView) view).isChecked()) {
                ((CheckedTextView) view).setChecked(false);
            } else {
                ((CheckedTextView) view).setChecked(true);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.prologue_activity);


        Vector<CheckedTextView> checkLists = new Vector<CheckedTextView>(CHECKCOUNT);
        //체크드텍스트뷰를 순서대로 담을 벡터

        CheckedTextView cseinfo = (CheckedTextView)findViewById(R.id.cseinfo_chkTextView);
        cseinfo.setOnClickListener(chkBoxListener);
        CheckedTextView collageinfo = (CheckedTextView)findViewById(R.id.collageinfo_chkTextView);
        collageinfo.setOnClickListener(chkBoxListener);
        CheckedTextView normalinfo = (CheckedTextView)findViewById(R.id.normalinfo_chkTextView);
        normalinfo.setOnClickListener(chkBoxListener);
        //체크박스 관련 리스너를 만들어서 붙여줌
        checkLists.add(cseinfo);
        checkLists.add(collageinfo);
        checkLists.add(normalinfo);

        //Toast.makeText(this, "테이블 중복생성 오류", Toast.LENGTH_SHORT).show();
        String defVal = "";
        for (int i = 0; i < CHECKCOUNT; i++) {
            defVal += "F";
        }
        SharedPreferences loadCheckedBefore = getSharedPreferences("checkLogPreference", Activity.MODE_PRIVATE);
        String loadData = loadCheckedBefore.getString("checkLog", defVal);
        for (int i = 0; i < loadData.length()/*==CHECKCOUNT*/; i++) {
            switch (loadData.charAt(i)) {
                case 'T':
                    checkLists.get(i).setChecked(true);
                    break;
                case 'F':
                    checkLists.get(i).setChecked(false);
                    break;
            }
        }


        boolean checkArray[] = new boolean[CHECKCOUNT];
        //체크드텍스트뷰의 체크값을 저장해서 다음 레이아웃에 보낼 배열


        Button nextBtn = (Button)findViewById(R.id.nextBtn);
        nextBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                int trueCheckCounter = 0;

                for (int i = 0; i < CHECKCOUNT; i++) {
                    if ((checkLists.get(i)).isChecked() == true) {
                        checkArray[i] = true;
                        trueCheckCounter++;
                    } else {
                        checkArray[i] = false;
                    }
                }

                if (trueCheckCounter >= 1) {
                    SharedPreferences saveChecked = getSharedPreferences("checkLogPreference", Activity.MODE_PRIVATE);
                    SharedPreferences.Editor e = saveChecked.edit();

                    String saveData = "";
                    for (int i = 0; i < CHECKCOUNT; i++) {
                        if (checkArray[i] == true)
                            saveData += "T";
                        else
                            saveData += "F";
                    }
                    e.putString("checkLog", saveData);
                    e.commit();

                    Intent i = new Intent(MainActivity.this, ViewInfoBoardActivity.class);
                    i.putExtra("checkArray", checkArray);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "아무 것도 체크하지 않았습니다!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
