package bae1776.first.gather_informations;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.first.gather_informations.R;

import java.util.List;

public class PostCustomViewAdapter_Deprecated extends BaseAdapter {

    Context con; //뷰를 띄울 Parent
    List<InfoPost> data;

    public PostCustomViewAdapter_Deprecated(Context c, List<InfoPost> d) {
        con = c;
        data = d;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //데이터가 셋팅된 한줄 모양 리턴

        //inflater로 객체화된 뷰를 넣을 Linearlayout
        LinearLayout layout = new LinearLayout(con);

        InfoPost post = data.get(position);

        LayoutInflater inflater = (LayoutInflater) con.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.postcustomview/*한줄에 넣을 뷰 모양*/, layout);

        TextView postResource = layout.findViewById(R.id.postResource);
        TextView title = layout.findViewById(R.id.title);
        TextView writer = layout.findViewById(R.id.writer);
        TextView date = layout.findViewById(R.id.date);
        TextView hit = layout.findViewById(R.id.hit);

        postResource.setText(post.postResource);
        title.setText(post.title);
        writer.setText(post.bbs_writer);
        date.setText(post.bbs_date.toString());
        hit.setText(post.bbs_hit);

        return layout;


    }


    @Override
    public int getCount() {
        return data.size();
    }

    @Override //일단은 필요 없는 메소드
    public Object getItem(int position) {
        return null;
    }

    @Override //일단은 필요 없는 메소드
    public long getItemId(int position) {
        return 0;
    }


}
