package bae1776.first.gather_informations;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.first.gather_informations.R;

import java.util.List;

public class PostRecyclerViewAdapter extends RecyclerView.Adapter<PostRecyclerViewAdapter.postViewHolder> {

    public interface ItemClickListener {
        void onItemClick(View v, String url);
    }

    List<InfoPost> data;
    private ItemClickListener cListener = null;

    //RecyclerView는 ListView와는 달리, 스크롤로 인해 더 이상 보이지 않게 되는 라인은 파괴시키고, 새로 보이는 라인은 다시 보여줌으로서
    //대용량의 리스트도 공간 낭비없이 볼 수 있게하는 향상된 ListView이다.
    //이에 따른 단점도 있긴하다..

    public PostRecyclerViewAdapter(List<InfoPost> d) {
        this.data = d;
    }

    @NonNull
    //한 줄에 item(값)을 띄울 모양을 저장하는 클래스가 ViewHolder 이다.
    @Override
    public postViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //ViewHolder 모양을 생성하는 메소드 (강제 오버라이드)

        LayoutInflater inflater = LayoutInflater.from(parent.getContext()); //inflate하여 사용할 장소(Context) 결정.
        //                      = parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); 와 다를 바 없는듯.
        View itemView = inflater.inflate(R.layout.postcustomview, /*root*/parent, false);
        //postcustomview를 객체화해 root 메모리에 올려(inflating) postcustomview 내부 객체를 사용할 수 있게 한다.

        return new postViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull postViewHolder holder, int position) {
        //뷰 모양(ViewHolder)에 묶여 들어갈 개체 값 정의.
        InfoPost datum = data.get(position);
        holder.setItem(datum);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(ItemClickListener listener) {
        this.cListener = listener;    //cListener에 Activity에서 오버라이딩된 Onclick 정보를 넣는다.
    }



    //값을 띄울 모양
    public class postViewHolder extends RecyclerView.ViewHolder {

        String clickLink = "";
        TextView postResourceT;
        TextView titleT;
        TextView writerT;
        TextView dateT;
        TextView hitT;

        //생성자를 부르고 super(itemView) 입력은 강제 사항 <-- onCreateViewHolder의 마지막 줄에서 호출됨
        public postViewHolder(View itemView) {
            super(itemView);

            //inflate된 R.layout.postcustomview --대입--> itemView의 뷰 객체를 일단 저장해둠
            postResourceT = itemView.findViewById(R.id.postResource);
            titleT = itemView.findViewById(R.id.title);
            writerT = itemView.findViewById(R.id.writer);
            dateT = itemView.findViewById(R.id.date);
            hitT = itemView.findViewById(R.id.hit);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (cListener != null) {
                        cListener.onItemClick(v, clickLink);  //Callback to Activity
                    }
                }
            });

        }

        //onBindViewHolder 메소드가 부르는 메소드이다.
        public void setItem(InfoPost item) {
            clickLink = item.clickLink; //최적화로서 좋은지는 잘 모르겠다..
            postResourceT.setText(item.postResource);
            titleT.setText(item.title);
            writerT.setText(item.bbs_writer);
            dateT.setText(item.bbs_date.toString());
            hitT.setText(item.bbs_hit);

        }
    }

}
