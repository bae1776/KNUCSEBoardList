package bae1776.first.gather_informations;


public class SimpleDate {
        String year;
        String month;
        String date;

        @Override
        public String toString() {
            return year + "-" + month + "-" + date;
        }

        public void StringToSimpleDate(String org) {
            String[] dateSpliter = org.split("-", 3);
            year = dateSpliter[0];
            month = dateSpliter[1];
            date = dateSpliter[2];
        }

        public boolean isMoreRecentThen(SimpleDate target) {
            int thisYear = Integer.parseInt(this.year);
            int targetYear = Integer.parseInt(target.year);
            if (thisYear > targetYear) return true;
            else if (thisYear < targetYear) return false;
            else {
                int thisMonth = Integer.parseInt(this.month);
                int targetMonth = Integer.parseInt(target.month);
                if (thisMonth > targetMonth) return true;
                else if (thisMonth < targetMonth) return false;
                else {
                    if (Integer.parseInt(this.date) > Integer.parseInt(target.date)) return true;
                    else return false;
                }
            }
        }

        public boolean isOlderThen(SimpleDate target) {
            return !this.isMoreRecentThen(target);
        }

}
