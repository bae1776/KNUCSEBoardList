package bae1776.first.gather_informations;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.first.gather_informations.R;

import java.util.ArrayList;

public class ViewInfoBoardActivity extends Activity {

////    class networkThread extends Thread { //쓰레드는 UI엔 관여 불가
//일단은 1페이지 정보를 다들 받아와서 뿌리는데에 집중을 하자.

      //ListView postView;  //게시판 형식으로 나타낼 리스트 뷰 그 자체
      RecyclerView postView;
      boolean alwaysConnectWebPage = false;
      Button viewMore;

//    class MyHandler extends Handler {
//        @Override
//        //Callback Method
//        public void handleMessage(Message msg) {
////            //이 메소드 내의 코드는 MainThread의 sendEmptyMessage에 의해 실행됨.
////            //(1) ListView
////            postView = (ListView)findViewById(R.id.postView);
////            //tv.setText(result.trim());
////            //(2), (3) -> ListView에 공급되는 데이터, 글 객체를 묶는 변수는 postList
////            PostCustomViewAdapter_Deprecated customAdapter = new PostCustomViewAdapter_Deprecated(ViewInfoBoardActivity.this,
////            CombinedPostList);
////            //(4) Adapter 적용.
////            postView.setAdapter(customAdapter);
//        }
//    }
//    MyHandler m = new MyHandler();


    ArrayList<InfoBoard> getInfoBoardList = new ArrayList<>();
    ArrayList<InfoPost> CombinedPostList = new ArrayList<>();
    SimpleDate postDateQueue[];

    CSENoticeInfoBoard cseNotices = null;
    final static int CSENotice = 0;
    CollageNoticeInfoBoard collageNotices = null;
    final static int CollageNotice = 1;
    NormalNoticeInfoBoard normalNotices = null;
    final static int NormalNotice = 2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewinfoboard_activity);

        TextView infoHead = (TextView)findViewById(R.id.infoHead);

        Intent checkArrayFromMainActivity = getIntent();
        boolean[] checkArray = checkArrayFromMainActivity.getExtras().getBooleanArray("checkArray");

        if (checkArray[CSENotice] == true) {
            cseNotices = new CSENoticeInfoBoard();
            getInfoBoardList.add(cseNotices.getInfoPostData());
        }
        if (checkArray[CollageNotice] == true) {
            collageNotices = new CollageNoticeInfoBoard();
            getInfoBoardList.add(collageNotices.getInfoPostData());
        }
        if (checkArray[NormalNotice] == true) {
            normalNotices = new NormalNoticeInfoBoard();
            getInfoBoardList.add(normalNotices.getInfoPostData());
        }

        for (int i = 0; i < getInfoBoardList.size(); i++) {
            try {
                getInfoBoardList.get(i).networkThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        postDateQueue = new SimpleDate[getInfoBoardList.size()];

        for (int i = 0; i < getInfoBoardList.size(); i++) {
            postDateQueue[i] = getInfoBoardList.get(i).postList.getFirst().bbs_date;
        }

        addCombinedList();



        //m.sendEmptyMessage(0);

        //https://thepassion.tistory.com/294 의 도움을 받아 RecyclerView로 작성하였습니다.

        postView = findViewById(R.id.postrecyclerView); //리싸이클러뷰 필드 설정
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                ViewInfoBoardActivity.this, LinearLayoutManager.VERTICAL, false);
        postView.setLayoutManager(layoutManager);
        //구분선 추가
        postView.addItemDecoration(new DividerItemDecoration(postView.getContext(), layoutManager.getOrientation()));

        PostRecyclerViewAdapter viewAdapter = new PostRecyclerViewAdapter(CombinedPostList);
        //RecyclerView에 클릭이벤트 추가하기(어려움) - 이중 콜백? : 간접적으로 Listener를 붙일 수 있음
        //Activity는 커스텀 리스너(ItemClickListener)를 부르고, 이 리스너를 Adapter 내부에 적용한 후,
        //실질적 클릭 부분인 ViewHolder가 onItemClick(커스텀 리스너의 OnClick)을 콜백하도록 만든다.
        viewAdapter.setOnItemClickListener(new PostRecyclerViewAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View v, String url) {
                if (alwaysConnectWebPage == false) {
                    DialogInterface.OnClickListener dialogs = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case DialogInterface.BUTTON_POSITIVE:
                                    alwaysConnectWebPage = true;
                                case DialogInterface.BUTTON_NEGATIVE:
                                    connectWebPage(url);
                                    break;
                            }
                        }
                    };
                    new AlertDialog.Builder(ViewInfoBoardActivity.this)
                            .setMessage("클릭한 게시글 웹페이지로 이동할까요?")
                            .setPositiveButton("항상 예", dialogs)
                            .setNeutralButton("아니오", dialogs)
                            .setNegativeButton("한번만", dialogs)
                            .setTitle("Alert")
                            .setIcon(android.R.drawable.ic_dialog_alert)   /*인자에 팝업 창에 들어갈 아이콘 모양을 고를 수 있다.*/
                            .show()/*show를 빼먹지말자*/;
                } else
                    connectWebPage(url);
            }
        });
        postView.setAdapter(viewAdapter);

        viewMore = (Button)findViewById(R.id.viewMoreButton);
        viewMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int emptyIdx = 0;
                for (int i = 1; i < getInfoBoardList.size(); i++) {
                    if (getInfoBoardList.get(i).postList.isEmpty()) {
                        emptyIdx = i;
                        break;
                    }
                }

                InfoBoard refreshBoard = getInfoBoardList.get(emptyIdx);

                //get 메소드가 얕은 복사일 경우에만 유효함
                refreshBoard.setNextPage();
                refreshBoard.setRootURLAgain();
                refreshBoard.getInfoPostData();
                try {
                    refreshBoard.networkThread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                addCombinedList();
                viewAdapter.notifyDataSetChanged();
                viewMore.setEnabled(true);
            }
        });
    }

    public void connectWebPage(String url) {  //WebViewActivity로 넘어감
        Intent i = new Intent(ViewInfoBoardActivity.this, WebViewActivity.class);
        i.putExtra("url", url);
        startActivity(i);
    }

    public void addCombinedList() {
        while (true) {
            SimpleDate mostRecent = getInfoBoardList.get(0).postList.getFirst().bbs_date;
            int removeIdx = 0;
            for (int i = 1; i < getInfoBoardList.size(); i++) {
                SimpleDate temp = getInfoBoardList.get(i).postList.getFirst().bbs_date;
                if (temp.isMoreRecentThen(mostRecent)) {
                    mostRecent = temp; //얕은 복사에 의한 null Exception 주의
                    removeIdx = i;
                }
            }

            CombinedPostList.add(getInfoBoardList.get(removeIdx).postList.removeFirst());

            if (getInfoBoardList.get(removeIdx).postList.isEmpty()) break;
        }
    }



    //[참고]디바이스의 NetWork 상태 가져오기 -> 여러가지로 응용 가능
//        EditText result = new EditText(this);
//        //TextView는 줄 넘김이 자동적으로 안되서 EditText를 썼을 뿐.
//        String sResult = "";
//        ConnectivityManager mgr =
//                (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
//        NetworkInfo[] ani = mgr.getAllNetworkInfo();
//        //우변 메소드를 사용하려면 Network Permission이 필요하다.
//        //Alt+Enter를 해서 도움말을 통해 바로 해결할 수도 있다. (manifest에 스크립트가 한 줄 붙는다.)
//        for (NetworkInfo n : ani) {
//            sResult += (n.toString() + "\n\n");
//        }
//        NetworkInfo ni = mgr.getActiveNetworkInfo();
//        sResult += ("Active : \n" + ni.toString() + "\n");
//        result.setText(sResult);
//        setContentView(result);
}
